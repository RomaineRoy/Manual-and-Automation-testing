/**
 * 
 */
/**
 * 
 */
module AssigmentJavaProgram {
}