package Program;

import java.util.Scanner;

public class MenuDrivenProgramForArithmeticOperations {

	public static void main(String[] args) {
	System.out.println("Menu Driven Basic calculator");
	System.out.println("1.Addition");
	System.out.println("2.Subraction");
	System.out.println("3.Multipication");
	System.out.println("4.Division");
	Scanner ss= new Scanner(System.in);
	String g= ss.nextLine();
	
	System.out.println("enter the number A");
	int a=ss.nextInt();
	System.out.println("enter the number B");
	int b=ss.nextInt();
	switch(g) {
	case "Addition":
		System.out.println(a+b);
		break;
	case "Subraction":
		System.out.println(a-b);
		break;
	case "Multipication":
		System.out.println(a*b);
		break;
	case "Division":
		System.out.println(a/b);
		break;
	default:
		System.out.println("Please Enter the correct option from menu");
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	}
	
	
	
	

	}

}
