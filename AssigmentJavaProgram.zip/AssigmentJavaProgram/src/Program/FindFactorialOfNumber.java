package Program;

import java.util.Scanner;

public class FindFactorialOfNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the  Numbers");
		int a=s.nextInt();
		int b=a;
		int product=1;
		while(b>1) {
			
			product=product*b;
			b--;
			
			
		}
		
	System.out.println("factorial of "+a+" is "+product );

	}

}
