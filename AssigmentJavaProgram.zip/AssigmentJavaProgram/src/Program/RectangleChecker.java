package Program;
import java.util.Scanner;


public class RectangleChecker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner SS= new Scanner(System.in);
		System.out.println("Enter the  one side of rectangle");
		int w1=SS.nextInt();
		System.out.println("Enter the  other side of rectangle");
		int w2=SS.nextInt();
		if(w1>w2 ||w2>w1) {
			 
			System.out.println("Its  rectangle");

		}
		else {
			System.out.println("Its  Square");

			
		}

		
		
		
		
		
		
		
		
		
		

	}

}
