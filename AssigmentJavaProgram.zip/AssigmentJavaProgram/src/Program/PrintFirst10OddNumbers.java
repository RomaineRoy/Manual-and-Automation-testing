package Program;
import java.util.*;
public class PrintFirst10OddNumbers {

	public static void main(String[] args) {
		System.out.println("Enter the number of odd numbers needed to be printed");
		Scanner sc=new Scanner(System.in);
Integer aa= sc.nextInt();

int a=1;
while(aa>0) {
	
	System.out.println(a);
	a=a+2;
	aa=aa-1;
	
	
	
}
	}

}
