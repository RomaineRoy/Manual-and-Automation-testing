package Program;
import java.util.*;

public class AddAlltheEvenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ss= new Scanner(System.in);
System.out.println("Enter the digit" );

String st= ss.nextLine();
int q= Integer.parseInt(st);
int sum=0;
int a=q;
 while(a>0) {
	
	sum=sum+a;
	 
	 a=a-2;
	 
 }
System.out.println("Sum of Even Digit upto "+q+" is "+sum );
		
	}}	
		
		
		
		
		
		
		
		
	


