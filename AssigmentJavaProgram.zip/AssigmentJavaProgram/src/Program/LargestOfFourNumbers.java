package Program;
import java.util.*;

public class LargestOfFourNumbers {

	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the Four Numbers");
		int a=s.nextInt();
		int b=s.nextInt();
		int c=s.nextInt();
		int d= s.nextInt();
		if(a>=b && a>=c && a>=d) {
			System.out.println("Largest is "+a);
		}
		else if(b>=a && b>=c && b>=d){
			System.out.println("Largest is "+b);

		}
		else if(c>=a && c>=b && c>=d) {
			System.out.println("Largest is "+c);

		}
		else {
			System.out.println("Largest is "+d);

		}
		

	}

}
