package Program;

import java.util.Scanner;

public class LeapYearChecker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Enter the Year");
Scanner s=new Scanner(System.in);
int m=s.nextInt();


if((m%400==0) || (m%4==0 && m%100!=0)) {
	System.out.println(" leap year");

	
}
else {
	
	System.out.println("Not a leap year");

}

	}

}
