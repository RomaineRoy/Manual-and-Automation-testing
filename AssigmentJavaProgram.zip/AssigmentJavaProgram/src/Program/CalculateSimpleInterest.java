package Program;

import java.util.Scanner;

public class CalculateSimpleInterest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Sc= new Scanner(System.in);
		System.out.println("Enter principle amount :");
		long P=Sc.nextLong();
		System.out.println("Enter Interest rate");
		float I=Sc.nextFloat();
		System.out.println("Enter Time Period in year");
		int T=Sc.nextInt();
		
float cc= (P*I*T)/100;
System.out.println("Simple Interest accumulated after "+T+" time period over amount "+P+" is "+cc);

		

	}

}
