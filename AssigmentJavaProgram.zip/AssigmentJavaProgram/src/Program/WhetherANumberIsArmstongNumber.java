package Program;

import java.util.Scanner;

public class WhetherANumberIsArmstongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		int q= sc.nextInt();
		//to find the number of digits in a number
		int g =q;
		int i=0;
		
		while(g>0) {
			g=g/10;
			i=i+1;}
		
			
		System.out.println("Number of digit "+i);
		int sum=0,number=0,pow=i,k=q;
		//To find the sum of the power of digit
		while(k>0) {
			
			number=k%10;
			sum=(int) (sum+Math.pow(number,i));
			k=k/10;
			
			}
		if(q==sum){
		System.out.print("Is Armstrong Number");	
			
		}
		else {
			System.out.print("Not a Armstrong Number");
			
		}
		
		
		

	}

}
