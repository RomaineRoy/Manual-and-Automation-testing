package Program;

public class FourPatternPrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("-----------First pattern----------- ");
		
		for(int i=1; i<=5;i++){
			for(int j=1;j<=i;j++) {
				System.out.print("*");
				
			}
			System.out.println();
			
		}
		
		
		System.out.println("-----------Second pattern----------- ");
		
	
		
		for(int i=1; i<=5;i++){
			for(int j=1;j<=i;j++) {
				System.out.print(i);
				
			}
			System.out.println();
			
		}
		
		System.out.println("-----------Third pattern----------- ");
		
		for(int i=1; i<=5;i++){
			int t=1;
			for(int j=5;j>=i;j--) {
				System.out.print(t);
				t=t+1;
				
			}
			System.out.println();
			
		}
		
		System.out.println("-----------Fourth pattern----------- ");
		
		
		
		for(int i=1; i<=5;i++){
			int t=64;
		
			for(int j=1;j<=i;j++) {
				char d=(char) (t+j);
				System.out.print(d);
			
				
			}
			System.out.println();
			
		}
		
		
		
		
		
		
		
		
		
		
		

	}

}
