package Program;

import java.util.Scanner;

public class IfNumberIsPositiveOrNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc= new Scanner(System.in);
int a=sc.nextInt();
if(a>=0) {
	System.out.println("Its Positive Number");
}
else {
	System.out.println("Its Negative Number");
}


	}

}
