package Program;

import java.util.Scanner;

public class MultipicationTableofGivenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.print("Enter the number");
int a = sc.nextInt();
int product=1;
for(int i=1; i<=10;i++) {
	product=a*i;
	System.out.println(a + " * "+ i +" = "+product);
	
	
}

	}

}
