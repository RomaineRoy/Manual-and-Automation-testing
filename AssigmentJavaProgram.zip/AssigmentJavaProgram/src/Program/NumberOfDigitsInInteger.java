package Program;

import java.util.Scanner;

public class NumberOfDigitsInInteger {

	public static void main(String[] args) {
 Scanner s= new Scanner(System.in);
 int s1= s.nextInt();
 String ss =Integer.toString(s1) ;
 System.out.println(ss.length());
	
	
	}

}
